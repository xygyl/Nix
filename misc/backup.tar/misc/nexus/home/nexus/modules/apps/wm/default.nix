{
  imports = [
    ./fuzzel
    ./niri
  ];
}
