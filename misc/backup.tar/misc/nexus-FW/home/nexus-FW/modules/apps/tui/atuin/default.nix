{
  imports = [
    ./atuin.nix
  ];
}
