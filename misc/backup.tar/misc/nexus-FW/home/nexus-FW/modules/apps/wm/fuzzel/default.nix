{
  imports = [
    ./fuzzel.nix
  ];
}
