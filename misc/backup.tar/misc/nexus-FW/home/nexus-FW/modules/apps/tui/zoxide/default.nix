{
  imports = [
    ./zoxide.nix
  ];
}
