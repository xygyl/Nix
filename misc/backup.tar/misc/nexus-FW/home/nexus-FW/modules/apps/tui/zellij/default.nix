{
  imports = [
    ./zellij.nix
  ];
}
