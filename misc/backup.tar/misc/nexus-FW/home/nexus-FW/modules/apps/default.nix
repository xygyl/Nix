{
  imports = [
    ./games
    ./wm
    ./tui
  ];
}
