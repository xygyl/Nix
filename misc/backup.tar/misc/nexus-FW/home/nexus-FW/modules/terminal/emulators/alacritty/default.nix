{
  imports = [
    ./alacritty.nix
  ];
}
