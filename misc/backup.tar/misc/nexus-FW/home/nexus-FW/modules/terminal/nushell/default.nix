{
  imports = [
    ./nushell.nix
  ];
}
