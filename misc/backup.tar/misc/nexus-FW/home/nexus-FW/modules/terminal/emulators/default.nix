{
  imports = [
    ./alacritty
    ./kitty
    ./rio
  ];
}
