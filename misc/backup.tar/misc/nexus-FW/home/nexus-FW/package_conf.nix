{
  nixpkgs.config.permittedInsecurePackages = [];
}
