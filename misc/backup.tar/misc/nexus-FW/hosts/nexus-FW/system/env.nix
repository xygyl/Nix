{
  environment.sessionVariables = {
    EDITOR = "hx";
  };
}
